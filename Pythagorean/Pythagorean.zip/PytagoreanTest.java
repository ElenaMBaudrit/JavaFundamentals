public class PytagoreanTest {
    public static void main(String[] args) {
        Pythagorean hypotenuse = new Pythagorean();
        double c= hypotenuse.calculateHypotenuse(3,4);
        System.out.println(c);
    }
}
