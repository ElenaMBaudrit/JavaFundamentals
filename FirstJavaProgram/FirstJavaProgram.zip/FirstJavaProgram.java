public class FirstJavaProgram {
    public static void main(String[] arg){
        System.out.println("My name is Elena");
        System.out.println("I am 38 years old");
        System.out.println("My hometown is San Jose, Costa Rica");
    }
}