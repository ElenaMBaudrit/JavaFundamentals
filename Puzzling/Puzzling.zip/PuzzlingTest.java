import java.util.*;

public class PuzzlingTest {
    public static void main(String[] args){
        Puzzling iD = new Puzzling();
        // // String puzzling = iD.puzzling()
        // iD.firstPuzzle(new int[] {3,5,1,2,7,9,8,13,25,32});

        // String[] patito= {"Nancy", "Jinichi", "Fujibayashi", "Momochi", "Ishikawa"};
        // System.out.println(iD.secondPuzzle(patito));
    
        // String[] aBCD = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
        
        // iD.thirdPuzzle(aBCD);

        // System.out.println(iD.tenRandom55to100());

        // System.out.println(iD.tenRandomNum55To100SortedMinMax());
        // iD.tenRandomNum55To100SortedMinMax();
        
        // iD.newRandomString();
        // System.out.println(iD.newRandomString());

        iD.new10RandomString();
    }
}