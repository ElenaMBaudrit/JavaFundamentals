public class FizzBuzzTest {
    public static void main(String[] arg) {
        FizzBuzz iD = new FizzBuzz();
        String fizzBuzz = iD.fizzBuzz(16);
        System.out.println(fizzBuzz);
    }
}